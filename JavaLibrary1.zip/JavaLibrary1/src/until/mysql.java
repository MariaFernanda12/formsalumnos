/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Until;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author maria
 */
public class mysql {
    private static String db= "Escuela"; //Aqui van a cambiarlo por el nombre de su base de datos
private static String user= "root";
private static String pass= "";
private static String url= "jdbc:mysql://localhost/"+db;
private static Connection Conn;

public static Connection getConnect(){
try{
Class.forName("com.mysql.jdbc.Driver");
Conn=DriverManager.getConnection(url,user,pass);
}catch (ClassNotFoundException | SQLException e) {
JOptionPane.showMessageDialog(null,"ERROR:"+ e.getMessage());
}
return Conn;

}
}
