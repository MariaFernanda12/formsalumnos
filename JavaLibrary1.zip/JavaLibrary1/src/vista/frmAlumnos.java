/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

import Until.mysql;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author maria
 */
public class frmAlumnos extends javax.swing.JFrame {
      DefaultTableModel model;
 Connection conn;
 Statement sent;
 /**
 * Creates new form frmAlumnos
 */
 public frmAlumnos() { //Constructor del formulario
 initComponents();
 conn=mysql.getConnect(); //Asigna a la variable la clase de conexion
 LlenarTabla();
 Deshabilitar();
 InicializarBotones();
 }
void Deshabilitar() { // Funcion para deshabilitar los controles
 txtMat.setEnabled(true);
 txtNom.setEnabled(false);
 txtApe1.setEnabled(false);
 txtApe2.setEnabled(false);
 txtTel.setEnabled(false);
 txtIng.setEnabled(false);
 cmbSem.setEnabled(false);
 txtGru.setEnabled(false);
 txtFecNac.setEnabled(false);
 cmbGen.setEnabled(false);
}
void Habilitar() { // Funcion para habilitar los controles
 txtNom.setEnabled(true);
 txtApe1.setEnabled(true);
 txtApe2.setEnabled(true);
 txtTel.setEnabled(true);
 txtIng.setEnabled(true);
 txtFecNac.setEnabled(true);
 txtGru.setEnabled(true);
 cmbSem.setEnabled(true);
 cmbGen.setEnabled(true);
 txtApe1.requestFocus();
}
void Limpiar(){ // Función para eliminar el contenido de los controles
 txtMat.setText("");
 txtNom.setText("");
 txtApe1.setText("");
 txtApe2.setText("");
 txtTel.setText("");
 txtIng.setText("");
 txtGru.setText("");
 txtFecNac.setText("");
 cmbSem.setSelectedItem(" ");
 cmbGen.setSelectedItem(" ");
}
void InicializarBotones(){ // funcion para poner los botones en el estado inicial
 btnNuevo.setEnabled(true);
 btnGuardar.setEnabled(false);
 btnEliminar.setEnabled(false);
 btnModificar.setEnabled(false);
 btnCancelar.setEnabled(true);
 btnBuscar.setEnabled(true);
}
void LlenarTabla(){ //Función para llenar el control jTable1 con el contenido de la tabla
 try{
 String[]titulos={"Matricula","A.Paterno","A.Materno","Nombre","Telefono","Fecha Nacimiento","Año Ingreso","Genero","Semestre","Grupo"};
 String SQL = "SELECT * FROM alumnos"; // Ojo con el nombre de la tabla, que sea igual a la de ustedes
 model = new DefaultTableModel (null,titulos);
 sent= conn.createStatement();
 ResultSet rs = sent.executeQuery(SQL);
 String[]fila= new String[10];
 while (rs.next()){
 fila[0]=rs.getString("matricula"); //En esta seccion hay que observar los
 fila[1]=rs.getString("ape1Alu"); // nombres de los campos en su tabla
 fila[2]=rs.getString("ape2Alu"); // y cambiarlos en la tabla o en el 
 fila[3]=rs.getString("nomAlu"); // código segun lo decidan
 fila[4]=rs.getString("telAlum");
 fila[5]=rs.getString("fechaNac");
 fila[6]=rs.getString("anioIngreso");
 fila[7]=rs.getString("genero");
 fila[8]=rs.getString("semestre");
 fila[9]=rs.getString("grupo");
 model.addRow(fila);
 } 
 jTable1.setModel(model);
 }catch (Exception e) {
 JOptionPane.showMessageDialog(null,"ERROR:"+e.getMessage()); 
 } 
}
//Función para colocar en los controles el valor seleccionado de la tabla 
//o el valor encontrado con el boton buscar
public void ColocarValoresEnControles(String SQL){ 
 try{
 sent=conn.createStatement();
 ResultSet rs=sent.executeQuery(SQL);
 rs.next();
 txtMat.setEnabled(false);
 txtMat.setText(rs.getString("matricula")); // OJO con los nombres de los campos
 txtApe1.setText(rs.getString("ape1Alu")); // no va a marcar error, pero si
 txtApe2.setText(rs.getString("ape2Alu")); // el nombre esta diferente que en su tabla
 txtNom.setText(rs.getString("nomAlu")); // les va a marcar un error en la ejecucion
 txtTel.setText(rs.getString("telAlum"));
 txtFecNac.setText(rs.getString("fechaNac"));
 txtIng.setText(rs.getString("anioIngreso"));
 cmbGen.setSelectedItem(rs.getString("genero"));
 cmbSem.setSelectedItem(rs.getString("semestre"));
 txtGru.setText(rs.getString("grupo"));
 
 }catch (Exception e){
 JOptionPane.showMessageDialog(null,"ERROR:"+e.getMessage());
 }
}
//Muestra en la tabla el registro encontrado con el boton buscar
void MostrarResultado(String SQL){ 
 try{
 String[]titulos={"Matricula","A.Paterno","A.Materno","Nombre","Telefono","Fecha Nacimiento","Año Ingreso","Genero","Semestre","Grupo"};
 model = new DefaultTableModel (null,titulos);
 sent= conn.createStatement();
 ResultSet rs = sent.executeQuery(SQL);
 String[]fila= new String[11];
 while (rs.next()){
 fila[0]=rs.getString("matricula"); // OJO con los nombres de los campos
 fila[1]=rs.getString("ape1Alu");
 fila[2]=rs.getString("ape2Alu");
 fila[3]=rs.getString("nomAlu");
 fila[4]=rs.getString("telAlum");
 fila[5]=rs.getString("fechaNac");
 fila[6]=rs.getString("anioIngreso");
 fila[7]=rs.getString("genero");
 fila[8]=rs.getString("semestre");
 fila[9]=rs.getString("grupo");
 model.addRow(fila);
 } 
 jTable1.setModel(model);
 }catch(Exception e){
 JOptionPane.showMessageDialog(null,"ERROR:"+e.getMessage()); 
 }
}
void BuscarRegistro(){ //Función para buscar en la tabla el registro introducido en matricula con el boton buscar
try{
 String SQL="";
 if(txtMat.getText().equals("")){
 JOptionPane.showMessageDialog(null,"ERROR: Introduzca Matricula a buscar"); 
 }
 else{
 int vCod=Integer.parseInt(txtMat.getText());
 SQL = "SELECT * FROM Alumnos WHERE matricula="+vCod; // Ojo con el nombre de la tabla
 sent=conn.createStatement();
 ResultSet rs=sent.executeQuery(SQL);
 rs.next();
 if(rs.getRow()==0){
 JOptionPane.showMessageDialog(null,"ERROR: No se encontro el registro");
 txtMat.setText("");
 } else {
 Habilitar();
 ColocarValoresEnControles(SQL);
 MostrarResultado(SQL);
 btnNuevo.setEnabled(false);
 btnGuardar.setEnabled(true);
 btnEliminar.setEnabled(true);
 btnModificar.setEnabled(true);
 btnGuardar.setEnabled(false); 
 }
 }
 }catch (Exception e){
 JOptionPane.showMessageDialog(null,"ERROR:"+e.getMessage());
 }
} 
 /**
 * This method is called from within the constructor to initialize the form.
 * WARNING: Do NOT modify this code. The content of this method is always
 * regenerated by the Form Editor.
 */
 @SuppressWarnings("unchecked")
 
 //El generated code NO SE MUEVE PARA NADA, ni lo deben copiar
 //su fomulario lo generará automaticamente
 // <editor-fold defaultstate="collapsed" desc="Generated Code"> 
 private void initComponents() {
 jLabel1 = new javax.swing.JLabel();
 jLabel2 = new javax.swing.JLabel();
 txtMat = new javax.swing.JTextField();
 btnNuevo = new javax.swing.JButton();
 btnGuardar = new javax.swing.JButton();
 btnModificar = new javax.swing.JButton();
 btnEliminar = new javax.swing.JButton();
 btnCancelar = new javax.swing.JButton();
 jPanel1 = new javax.swing.JPanel();
 txtApe1 = new javax.swing.JTextField();
 jLabel3 = new javax.swing.JLabel();
 txtApe2 = new javax.swing.JTextField();
 jLabel4 = new javax.swing.JLabel();
 txtNom = new javax.swing.JTextField();
 jLabel5 = new javax.swing.JLabel();
 cmbGen = new javax.swing.JComboBox<>();
 jLabel11 = new javax.swing.JLabel();
 txtIng = new javax.swing.JTextField();
 jLabel8 = new javax.swing.JLabel();
 txtTel = new javax.swing.JTextField();
 jLabel7 = new javax.swing.JLabel();
 txtFecNac = new javax.swing.JTextField();
 jLabel6 = new javax.swing.JLabel();
 jLabel9 = new javax.swing.JLabel();
 cmbSem = new javax.swing.JComboBox<>();
 txtGru = new javax.swing.JTextField();
 jLabel10 = new javax.swing.JLabel();
 jScrollPane1 = new javax.swing.JScrollPane();
 jTable1 = new javax.swing.JTable();
 btnBuscar = new javax.swing.JButton();
 setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
 jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
 jLabel1.setText("Registro de Alumnos");
 jLabel2.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
 jLabel2.setText("Matricula:");
 txtMat.setName(""); // NOI18N
 btnNuevo.setText("Nuevo");
 btnNuevo.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
 public void mouseMoved(java.awt.event.MouseEvent evt) {
 NuevoMouseEncima(evt);
 }
 });
 btnNuevo.addActionListener(new java.awt.event.ActionListener() {
 public void actionPerformed(java.awt.event.ActionEvent evt) {
 btnNuevoActionPerformed(evt);
 }
 });
 btnGuardar.setText("Guardar");
 btnGuardar.addActionListener(new java.awt.event.ActionListener() {
 public void actionPerformed(java.awt.event.ActionEvent evt) {
 btnGuardarActionPerformed(evt);
 }
 });
 btnModificar.setText("Modificar");
 btnModificar.addActionListener(new java.awt.event.ActionListener() {
 public void actionPerformed(java.awt.event.ActionEvent evt) {
 btnModificarActionPerformed(evt);
 }
 });
 btnEliminar.setText("Eliminar");
 btnEliminar.addActionListener(new java.awt.event.ActionListener() {
 public void actionPerformed(java.awt.event.ActionEvent evt) {
 btnEliminarActionPerformed(evt);
 }
 });
 btnCancelar.setText("Cancelar");
 btnCancelar.addActionListener(new java.awt.event.ActionListener() {
 public void actionPerformed(java.awt.event.ActionEvent evt) {
 btnCancelarActionPerformed(evt);
 }
 });
 jPanel1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
 jLabel3.setText("Apellido Paterno");
 jLabel4.setText("Apellido Materno");
 jLabel5.setText("Nombre(s)");
 cmbGen.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { " ", "F", "M" }));
 jLabel11.setText("Genero");
 jLabel8.setText("Año de Ingreso");
 jLabel7.setText("Telefono");
 txtFecNac.setText("AAAA-MM-DD");
 jLabel6.setText("Fecha Nacimiento");
 jLabel9.setText("Semestre:");
 cmbSem.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { " ", "1", "2", "3", "4", "5", "6" }));
 jLabel10.setText("Grupo:");
 javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
 jPanel1.setLayout(jPanel1Layout);
 jPanel1Layout.setHorizontalGroup(
 jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
 .addGroup(jPanel1Layout.createSequentialGroup()
 .addGap(25, 25, 25)
 .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
 .addGroup(jPanel1Layout.createSequentialGroup()
 .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
 .addGroup(jPanel1Layout.createSequentialGroup()
 .addGap(55, 55, 55)
 .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
 .addGap(37, 37, 37)
 .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
 .addGroup(jPanel1Layout.createSequentialGroup()
 .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
 .addGroup(jPanel1Layout.createSequentialGroup()
 .addGap(14, 14, 14)
 .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
 .addGroup(jPanel1Layout.createSequentialGroup()
 .addComponent(jLabel9)
 .addGap(18, 18, 18)
 .addComponent(cmbSem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
 .addGap(62, 62, 62)
 .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
 .addComponent(txtFecNac, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
 .addGroup(jPanel1Layout.createSequentialGroup()
 .addGap(122, 122, 122)
 .addComponent(jLabel10)
 .addGap(18, 18, 18)
 .addComponent(txtGru, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
 .addGroup(jPanel1Layout.createSequentialGroup()
 .addGap(192, 192, 192)
 .addComponent(txtIng, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)))
 .addGap(60, 60, 60)
 .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
 .addGroup(jPanel1Layout.createSequentialGroup()
 .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, 47, Short.MAX_VALUE)
 .addGap(14, 14, 14))
 .addGroup(jPanel1Layout.createSequentialGroup()
 .addComponent(cmbGen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
 .addGap(0, 0, Short.MAX_VALUE))))
 .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
 .addComponent(txtApe1, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
 .addGap(21, 21, 21)
 .addComponent(txtApe2, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
 .addGap(18, 24, Short.MAX_VALUE)
 .addComponent(txtNom, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)))
 .addGap(26, 26, 26))
 .addGroup(jPanel1Layout.createSequentialGroup()
 .addGap(34, 34, 34)
 .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
 .addComponent(txtTel, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
 .addComponent(jLabel3))
 .addGap(102, 102, 102)
 .addComponent(jLabel4)
 .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
 .addComponent(jLabel5)
 .addGap(93, 93, 93))))
 );
 jPanel1Layout.setVerticalGroup(
 jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
 .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
 .addContainerGap(28, Short.MAX_VALUE)
 .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
 .addComponent(txtApe1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
 .addComponent(txtApe2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
 .addComponent(txtNom, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
 .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
 .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
 .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
 .addComponent(jLabel4)
 .addComponent(jLabel5))
 .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
 .addGroup(jPanel1Layout.createSequentialGroup()
 .addGap(16, 16, 16)
 .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
 .addComponent(txtIng, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
 .addComponent(cmbGen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
 .addGroup(jPanel1Layout.createSequentialGroup()
 .addGap(18, 18, 18)
 .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
 .addComponent(txtTel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
 .addComponent(txtFecNac, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
 .addGap(13, 13, 13)
 .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
 .addComponent(jLabel8)
 .addComponent(jLabel7)
 .addComponent(jLabel6)
 .addComponent(jLabel11))
 .addGap(18, 18, 18)
 .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
 .addComponent(txtGru, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
 .addComponent(jLabel10)
 .addComponent(cmbSem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
 .addComponent(jLabel9))
 .addGap(0, 17, Short.MAX_VALUE))
 );
 jTable1.setModel(new javax.swing.table.DefaultTableModel(
 new Object [][] {
 {null, null, null, null},
 {null, null, null, null},
 {null, null, null, null},
 {null, null, null, null}
 },
 new String [] {
 "Title 1", "Title 2", "Title 3", "Title 4"
 }
 ));
 jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
 public void mouseClicked(java.awt.event.MouseEvent evt) {
 jTable1MouseClicked(evt);
 }
 });
 jScrollPane1.setViewportView(jTable1);
 btnBuscar.setText("Buscar");
 btnBuscar.setName(""); // NOI18N
 btnBuscar.addActionListener(new java.awt.event.ActionListener() {
 public void actionPerformed(java.awt.event.ActionEvent evt) {
 btnBuscarActionPerformed(evt);
 }
 });
 javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
 getContentPane().setLayout(layout);
 layout.setHorizontalGroup(
 layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
 .addGroup(layout.createSequentialGroup()
 .addGap(27, 27, 27)
 .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
 .addGroup(layout.createSequentialGroup()
 .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
 .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
 .addGroup(layout.createSequentialGroup()
 .addGap(167, 167, 167)
 .addComponent(jLabel2)
 .addGap(18, 18, 18)
 .addComponent(txtMat, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
 .addGap(30, 30, 30)
 .addComponent(btnBuscar)))
 .addGap(18, 18, 18)
 .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
 .addComponent(btnNuevo)
 .addComponent(btnGuardar)
 .addComponent(btnModificar)
 .addComponent(btnEliminar)
 .addComponent(btnCancelar))
 .addGap(0, 25, Short.MAX_VALUE))
 .addGroup(layout.createSequentialGroup()
 .addGap(195, 195, 195)
 .addComponent(jLabel1)
 .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
 .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
 .addGap(28, 28, 28)
 .addComponent(jScrollPane1)
 .addGap(25, 25, 25))
 );
 layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {btnCancelar, btnEliminar, btnGuardar, btnModificar, btnNuevo});
 layout.setVerticalGroup(
 layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
 .addGroup(layout.createSequentialGroup()
 .addGap(21, 21, 21)
 .addComponent(jLabel1)
 .addGap(18, 18, 18)
 .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
 .addComponent(txtMat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
 .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
 .addComponent(btnBuscar))
 .addGap(18, 18, 18)
 .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
 .addGroup(layout.createSequentialGroup()
 .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
 .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
 .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE))
 .addGroup(layout.createSequentialGroup()
 .addComponent(btnNuevo)
 .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
 .addComponent(btnGuardar)
 .addGap(14, 14, 14)
 .addComponent(btnModificar)
 .addGap(14, 14, 14)
 .addComponent(btnEliminar)
 .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
 .addComponent(btnCancelar)))
 .addContainerGap(19, Short.MAX_VALUE))
 );
 pack();
 }// </editor-fold> 
//OJO!!! La primera linea y las llaves de cada evento se genera desde el formulario, 
// lo que deben copiar es unicamente el contenido del evento
 private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) { 
 Limpiar();
 Deshabilitar();
 InicializarBotones();
 LlenarTabla(); 
 } 
 private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) { 
 try {
 String SQL = "INSERT INTO Alumnos(matricula,ape1Alu,ape2Alu,nomAlu,telAlum,fechaNac,anioIngreso,genero,semestre,grupo)"
 +"VALUES (?,?,?,?,?,?,?,?,?,?)"; // Ojo con el nombre de la tabla y de los campos
 PreparedStatement ps= conn.prepareStatement(SQL);
 ps.setString(1, txtMat.getText());
 ps.setString(2, txtApe1.getText());
 ps.setString(3, txtApe2.getText());
 ps.setString(4, txtNom.getText());
 ps.setString(5, txtTel.getText());
 ps.setString(6, txtFecNac.getText());
 ps.setString(7, txtIng.getText());
 ps.setString(8, (String) cmbGen.getSelectedItem());
 ps.setString(9,(String) cmbSem.getSelectedItem());
 ps.setString(10, txtGru.getText());
 int n=ps.executeUpdate(); 
 if(n>0){
 Limpiar();
 Deshabilitar();
 InicializarBotones();
 }
 JOptionPane.showMessageDialog(null,"Datos Guardados Correctamente");
 LlenarTabla();
 }catch (Exception e){
 JOptionPane.showMessageDialog(null,"ERROR:"+e.getMessage());
 }
 } 
 private void jTable1MouseClicked(java.awt.event.MouseEvent evt) { 
 btnEliminar.setEnabled(true);
 btnGuardar.setEnabled(false);
 btnModificar.setEnabled(true);
 btnBuscar.setEnabled(false);
 btnNuevo.setEnabled(false);
 btnCancelar.setEnabled(true);
 if(evt.getButton()==1){
 int fila = jTable1.getSelectedRow();
 Habilitar();
 try{
 String SQL = "SELECT * FROM alumnos WHERE matricula="+jTable1.getValueAt(fila,0);// Ojo con el nombre de la tabla y del campo
 ColocarValoresEnControles(SQL);
 }catch (Exception e){
 JOptionPane.showMessageDialog(null,"ERROR:"+e.getMessage());
 }
 } // TODO add your handling code here:
 } 
 private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) { 
 int fila = jTable1.getSelectedRow();
 try{
 String SQL = "DELETE FROM Alumnos WHERE matricula="+jTable1.getValueAt(fila,0); // Ojo con el nombre de la tabla y del campo
 sent = conn.createStatement();
 int n = sent.executeUpdate(SQL);
 if (n>0){
 Limpiar();
 Deshabilitar();
 InicializarBotones();
 LlenarTabla();
 JOptionPane.showMessageDialog(null,"Registro Eliminado Correctamente");
 }
 }catch (Exception e){
 JOptionPane.showMessageDialog(null,"ERROR:"+e.getMessage());
 }
 } 
 private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) { 
 BuscarRegistro(); 
 } 
 private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) { 
 try {
 String SQL = "UPDATE alumnos SET ape1Alu=?,ape2Alu=?,nomAlu=?,telAlum=?,fechaNac=?,anioIngreso=?,genero=?,semestre=?,grupo=?"
 +"WHERE matricula=?"; // Ojo con el nombre de la tabla y de los campos
 PreparedStatement ps= conn.prepareStatement(SQL);
 ps.setString(1, txtApe1.getText());
 ps.setString(2, txtApe2.getText());
 ps.setString(3, txtNom.getText());
 ps.setString(4, txtTel.getText());
 ps.setString(5, txtFecNac.getText());
 ps.setString(6, txtIng.getText());
 ps.setString(7, (String) cmbGen.getSelectedItem());
 ps.setString(8,(String) cmbSem.getSelectedItem());
 ps.setString(9, txtGru.getText());
 ps.setString(10, txtMat.getText());
 int n=ps.executeUpdate(); 
 if(n>0){
 Limpiar();
 Deshabilitar();
 InicializarBotones();
 }
 JOptionPane.showMessageDialog(null,"Datos Actualizados Correctamente");
 LlenarTabla();
 }catch (Exception e){
 JOptionPane.showMessageDialog(null,"ERROR:"+e.getMessage());
 }
 } 
 private void NuevoMouseEncima(java.awt.event.MouseEvent evt) { 
 // TODO add your handling code here:
 } 
 private void btnNuevoActionPerformed(java.awt.event.ActionEvent evt) { 
 Habilitar();
 Limpiar();
 btnNuevo.setEnabled(false);
 btnGuardar.setEnabled(true);
 btnEliminar.setEnabled(false);
 btnModificar.setEnabled(false);
 btnBuscar.setEnabled(false);
 } 
// OJO - DE AQUI EN ADELANTE NO SE MODIFICA ABSOLUTAMENTE NADA!!!
// ESTE CODIGO LO GENERA AUTOMATICAMENTE EL PROGRAMA
 /**
 * @param args the command line arguments
 */
 public static void main(String args[]) {
 /* Set the Nimbus look and feel */
 //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
 /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
 * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
 */
 try {
 for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
 if ("Nimbus".equals(info.getName())) {
 javax.swing.UIManager.setLookAndFeel(info.getClassName());
 break;
 }
 }
 } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
 java.util.logging.Logger.getLogger(frmAlumnos.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
 }
 //</editor-fold>
 /* Create and display the form */
 java.awt.EventQueue.invokeLater(() -> {
     new frmAlumnos().setVisible(true);
 });
 }
 // Variables declaration - do not modify 
 private javax.swing.JButton btnBuscar;
 private javax.swing.JButton btnCancelar;
 private javax.swing.JButton btnEliminar;
 private javax.swing.JButton btnGuardar;
 private javax.swing.JButton btnModificar;
 private javax.swing.JButton btnNuevo;
 private javax.swing.JComboBox<String> cmbGen;
 private javax.swing.JComboBox<String> cmbSem;
 private javax.swing.JLabel jLabel1;
 private javax.swing.JLabel jLabel10;
 private javax.swing.JLabel jLabel11;
 private javax.swing.JLabel jLabel2;
 private javax.swing.JLabel jLabel3;
 private javax.swing.JLabel jLabel4;
 private javax.swing.JLabel jLabel5;
 private javax.swing.JLabel jLabel6;
 private javax.swing.JLabel jLabel7;
 private javax.swing.JLabel jLabel8;
 private javax.swing.JLabel jLabel9;
 private javax.swing.JPanel jPanel1;
 private javax.swing.JScrollPane jScrollPane1;
 private javax.swing.JTable jTable1;
 private javax.swing.JTextField txtApe1;
 private javax.swing.JTextField txtApe2;
 private javax.swing.JTextField txtFecNac;
 private javax.swing.JTextField txtGru;
 private javax.swing.JTextField txtIng;
 private javax.swing.JTextField txtMat;
 private javax.swing.JTextField txtNom;
 private javax.swing.JTextField txtTel;
 // End of variables declaration 
}
